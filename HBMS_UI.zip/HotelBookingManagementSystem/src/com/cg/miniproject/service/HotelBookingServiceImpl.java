package com.cg.miniproject.service;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.dao.IHotelBookingDao;
import com.cg.miniproject.dao.HotelBookingDaoImpl;
import com.cg.miniproject.exception.HotelException;
@Service
public class HotelBookingServiceImpl implements IHotelBookingService {

	@Autowired 
	IHotelBookingDao dao;
	public boolean register(User user) throws HotelException {
		return dao.register(user);
	}

	public User login(User user) throws HotelException {
		return dao.login(user);

	}

	@Override
	public boolean addHotels(Hotel hotel) throws HotelException {


		return dao.addHotels(hotel);
	}

	@Override
	public boolean deleteHotel(Integer id) throws HotelException {
		return dao.deleteHotel(id);

	}

	@Override
	public boolean addRooms(RoomDetails roomDetails) throws HotelException {

		return dao.addRooms(roomDetails);
	}

	@Override
	public boolean deleteRoom(Integer id) throws HotelException {

		return dao.deleteRooms(id);
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(Integer hotelId)
			throws HotelException {

		return dao.retrieveBookings(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(LocalDate date)
			throws HotelException {

		return dao.retrieveBookings(date);
	}

	public ArrayList<Hotel> getHotelList() throws HotelException {
		return dao.getHotelList();
	}

	public ArrayList<RoomDetails> getRoomDetails(Integer id)
			throws HotelException {
		return dao.getRoomDetails(id);
	}

	@Override
	public BookingDetails insertBookingDetails(BookingDetails bookingDetails)
			throws HotelException {
		return dao.insertBookingDetails(bookingDetails);
	}

	@Override
	public User fetchUserId(User user) throws HotelException {

		return dao.fetchUserId(user);
	}

	@Override
	public boolean validateName(User user) throws HotelException {
		return dao.validateName(user);
	}

	@Override
	public BookingDetails retrieveGuestList(Integer hotelId)
			throws HotelException {
		return dao.retrieveGuestList(hotelId);
	}

	public boolean viewBookingStatus(Integer userId) throws HotelException {
		return dao.viewBookingStatus(userId);
	}

	@Override
	public boolean modifyHotel(Hotel hotel) throws HotelException {
		return dao.modifyHotel(hotel);
	}

	@Override
	public boolean modifyRoom(RoomDetails details) throws HotelException {
		return dao.modifyRoom(details);
	}

	@Override
	public boolean validateHotelId(Integer hotelId) throws HotelException {
		return dao.validateHotelId(hotelId);
	}

	@Override
	public ArrayList<Hotel> getHotelList(Integer hotelId) {
		return dao.getHotelList(hotelId);
	}
	@Override
	public ArrayList<RoomDetails> getRoomList(RoomDetails roomDetails){
		return dao.getRoomList(roomDetails);
		
	}

	@Override
	public boolean checkHotelId(Integer hotelId) {
		// TODO Auto-generated method stub
		return dao.checkHotelId(hotelId);
	}
}