/*package com.cg.miniproject.junit;


import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.junit.Test;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;
import com.cg.miniproject.service.HotelBookingServiceImpl;

public class HotelBookingServiceImplTest {
	HotelBookingServiceImpl impl=new HotelBookingServiceImpl();
	User user=new User();
	Hotel hotel = new Hotel(); 
	RoomDetails room=new RoomDetails();
	BookingDetails details = new BookingDetails();
	
	@Test
	public void testRegister() throws HotelException {
		user.setUserName("Ramu");
	    user.setPassword("ramu");
	    user.setRole("Employee");
		assertEquals(true, impl.register(user));
	}
	
	

	@Test
	public void testLogin() throws HotelException {
		user.setUserName("admin");
	    user.setPassword("admin");
	    user.setRole("Admin");
		assertEquals(true, impl.login(user));
	}
	
	@Test
	public void testLogin1() throws HotelException {
		user.setUserName("ram");
	    user.setPassword("qwerty");
	    user.setRole("Admin");
		assertEquals(true, impl.login(user));
	}

	@Test
	public void testAddHotels() throws HotelException {
		hotel.setHotelId("2007");
		hotel.setCity("Mumbai");
		hotel.setHotelName("IBIS Hotel");
		hotel.setAddress("Gandhi nagar");
		hotel.setAvgRatePerNight(3000.00);
		hotel.setDescription("4 star");
		assertEquals(true, impl.addHotels(hotel));
	}
	
	@Test
	public void testAddHotels1() throws HotelException {
		hotel.setHotelId("2007");
		hotel.setCity("Mumbai");
		hotel.setHotelName("IBIS Hotel");
		hotel.setAddress("Gandhi nagar");
		hotel.setAvgRatePerNight(3000.00);
		hotel.setDescription("4");
		assertEquals(true, impl.addHotels(hotel));
	}

	@Test
	public void testDeleteHotel() throws HotelException {
		assertEquals(true, impl.deleteHotel("2006"));
	}
	
	@Test
	public void testDeleteHotel1() throws HotelException {
		assertEquals(true, impl.deleteHotel("2008"));
	}

	@Test
	public void testAddRooms() throws HotelException {
		ArrayList<RoomDetails> list = new ArrayList<>();
		room.setHotelId("2004");
		room.setRoomId("1004");
		room.setRoomNo("104");
		room.setRoomType("Deluxe A/C room");
		room.setPerNightRate(5000.00);
		room.setAvailability("A");
		assertEquals(true, impl.addRooms(room));
	}
	
	@Test
	public void testAddRooms1() throws HotelException {
		ArrayList<RoomDetails> list = new ArrayList<>();
		room.setHotelId("2004");
		room.setRoomId("1004");
		room.setRoomNo("104");
		room.setRoomType("Deluxe A/C room");
		room.setPerNightRate(5000.00);
		room.setAvailability("A");
		assertEquals(true, impl.addRooms(room));
	}
	

	@Test
	public void testDeleteRoom() throws HotelException {
		assertEquals(true, impl.deleteRoom("7"));
	}
	
	@Test
	public void testDeleteRoom1() throws HotelException {
		assertEquals(true, impl.deleteRoom("7"));
	}

	@Test
	public void testRetrieveBookingsString() throws HotelException {
		ArrayList<BookingDetails> list = new ArrayList<>();
		list= impl.retrieveBookings("2001");
		for(BookingDetails b:list)
		assertEquals("1001", b.getRoomId());
	}
	
	@Test
	public void testRetrieveBookingsString1() throws HotelException {
		assertEquals(true, impl.retrieveBookings("2008"));
	}

	@Test
	public void testRetrieveBookingsLocalDate() throws HotelException {
		String date = "12/05/2018";

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date1 = LocalDate.parse(date, dtf);
		ArrayList<BookingDetails> list=new ArrayList<BookingDetails>();
		list = impl.retrieveBookings(date1);
		for(BookingDetails details:list)
		assertEquals("101", details.getRoomId());
	}

	@Test
	public void testGetHotelList() throws HotelException {
		ArrayList<Hotel> list = new ArrayList<>();
		list=impl.getHotelList();
		int count=0;
		for(Hotel h:list)
		{
			
			if(h.getCity().equals("Chennai"))
				++count;
		}
		assertEquals(true,count>0);
	}

	@Test
	public void testGetRoomDetails() throws HotelException {
		ArrayList<RoomDetails> list=new ArrayList<RoomDetails>();
		list=impl.getRoomDetails("2004");
		System.out.println(list);
		int count=0;
		for(RoomDetails rd:list)
		{
			if(rd.getRoomId().contains("1007"));
				++count;
		}
		assertEquals(true,count>0);
		
	}
	
	@Test
	public void testGetRoomDetails1() throws HotelException {
		assertEquals(true, impl.getRoomDetails("112"));
	}

	@Test
	public void testInsertBookingDetails() throws HotelException {
		details.setRoomId("1007");
		details.setUserId("1082");
		details.setBookedFrom("08/12/2018");
		details.setBookedTo("15/12/2018");
		details.setNoOfAdults(3);
		details.setNoOfChildren(3);
		details.setAmount(2000.00);
		assertEquals(true, impl.insertBookingDetails(details));
	}

	@Test
	public void testFetchUserId() throws HotelException {
		user.setUserName("Janvitha");
	    user.setPassword("janu");
	    user.setRole("User");
	    User user1=impl.fetchUserId(user);
	    assertEquals("1082",user1.getUserId() );
	}

	@Test
	public void testFetchUserId1() throws HotelException {
		user.setUserName("sairam");
	    user.setPassword("qwerty");
	    user.setRole("Admin");
	    User user1=impl.fetchUserId(user);
	    assertEquals("1051",user1.getUserId() );
	}

}*/