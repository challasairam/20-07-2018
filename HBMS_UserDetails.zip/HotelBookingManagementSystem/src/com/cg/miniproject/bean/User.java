package com.cg.miniproject.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
@Table(name="users")
@NamedQueries(@NamedQuery(name="login",query="select user from User user where user.userName=:uname and user.password=:pwd and user.role=:role"))
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="user_id")
	private Integer userId;
	@Pattern(regexp="^[A-Za-z]{1,7}$",message="Only characters are allowed")
	@Column(name="password")
	private String password;
	@Column(name="role")
	@NotEmpty(message="Select anyone")
	private String role;
	@Column(name="user_name")
	@NotEmpty(message="Cannot be empty")
	private String userName;
	@Column(name="mobile_no")
	@NotEmpty(message="Cannot be empty")
	@Pattern(regexp="^[0-9]{10}$",message="Should be of 10 digits only")
	private String mobileNo;
	@Column(name="phone")
	@NotEmpty(message="Cannot be empty")
	@Pattern(regexp="^[0-9]{10}$",message="Should be of 10 digits only")
	private String phone;
	@Column(name="address")
	@NotEmpty(message="Cannot be empty")
	private String address;
	@Column(name="email")
	@NotEmpty(message="Cannot be empty")
	@Pattern(regexp="^[A-Za-z0-9]+[@]+[a-z]+[.]+[a-z]{1,4}",message="Not a Valid email")
	private String email;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public User() {

	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", password=" + password + ", role="
				+ role + ", userName=" + userName + ", mobileNo=" + mobileNo
				+ ", phone=" + phone + ", address=" + address + ", email="
				+ email + "]";
	}

}
