package com.cg.miniproject.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "roomdetails")
@NamedQueries({@NamedQuery(name = "getRoomDetails", query = "select details from RoomDetails details where details.hotelId=:id and details.availability='A'"),@NamedQuery(name="checkhotel",query="select r from RoomDetails r where r.hotelId=:id")})
public class RoomDetails {
	@Column(name = "hotel_id")
	private Integer hotelId;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "room_id")
	private Integer roomId;
	@Column(name = "room_no")
	private String roomNo;
	@Column(name = "room_type")
	private String roomType;
	@Column(name = "per_night_rate")
	private Double perNightRate;
	@Column(name = "availability")
	private String availability;

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public Integer getHotelId() {
		return hotelId;
	}

	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}

	public Integer getRoomId() {
		return roomId;
	}

	public void setRoomId(Integer roomId) {
		this.roomId = roomId;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public Double getPerNightRate() {
		return perNightRate;
	}

	public void setPerNightRate(Double perNightRate) {
		this.perNightRate = perNightRate;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public RoomDetails() {

	}

	@Override
	public String toString() {
		return "RoomDetails [hotelId=" + hotelId + ", roomId=" + roomId
				+ ", roomNo=" + roomNo + ", roomType=" + roomType
				+ ", perNightRate=" + perNightRate + ", availability="
				+ availability + "]";
	}

}