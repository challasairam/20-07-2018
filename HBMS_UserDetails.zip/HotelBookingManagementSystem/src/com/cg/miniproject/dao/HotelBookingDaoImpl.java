package com.cg.miniproject.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;

@Repository
@Transactional
public class HotelBookingDaoImpl implements IHotelBookingDao {
	boolean b, result = false;

	@PersistenceContext
	EntityManager entityManager;

	/*
	 * To register a new user/employee
	 */
	@Override
	public boolean register(User user) throws HotelException {

		entityManager.persist(user);
		entityManager.flush();
		b = true;
		return b;
	}

	/*
	 * To login a user/employee
	 */
	public User login(User user) throws HotelException {

		Query query = entityManager.createNamedQuery("login");
		query.setParameter("uname", user.getUserName());
		query.setParameter("pwd", user.getPassword());
		query.setParameter("role", user.getRole());
		ArrayList<User> list = (ArrayList<User>) query.getResultList();
		User user2 = null;
		System.out.println(list.get(0).getUserId());
		if (!list.isEmpty())
			user.setUserId(list.get(0).getUserId());
			user2 = user;
		return user2;
	}

	/*
	 * To add Hotels in the hotel table
	 */
	@Override
	public boolean addHotels(Hotel hotel) throws HotelException {

		entityManager.persist(hotel);
		entityManager.flush();
		result = true;
		return result;
	}

	/*
	 * To delete hotel based on hotel Id
	 */
	@Override
	public boolean deleteHotel(Integer id) throws HotelException {

		Hotel hotel = entityManager.find(Hotel.class, id);
		entityManager.remove(hotel);
		result = true;
		return result;
	}

	/*
	 * To add new rooms for a particular hotel
	 */
	@Override
	public boolean addRooms(RoomDetails roomDetails) throws HotelException {

		return result;
	}

	/*
	 * To delete rooms for a particular hotel based on room id
	 */
	@Override
	public boolean deleteRooms(String id) throws HotelException {

		return result;
	}

	/*
	 * To retrieve bookings for a particular hotel based on hotel Id
	 */
	@Override
	public ArrayList<BookingDetails> retrieveBookings(String hotelId)
			throws HotelException {
		return null;

	}

	/*
	 * To retrieve bookings for a particular hotel based on Date
	 */
	@Override
	public ArrayList<BookingDetails> retrieveBookings(LocalDate date)
			throws HotelException {

		return null;

	}

	/*
	 * To retrieve list of hotels
	 */
	@Override
	public ArrayList<Hotel> getHotelList() throws HotelException {

		Query query = entityManager.createNamedQuery("listAllHotels");
		ArrayList<Hotel> list = (ArrayList<Hotel>) query.getResultList();
		return list;
	}

	/*
	 * To retrieve room details based on hotel Id
	 */
	@Override
	public ArrayList<RoomDetails> getRoomDetails(Integer id)
			throws HotelException {

		Query query = entityManager.createNamedQuery("getRoomDetails");
		query.setParameter("id", id);
		ArrayList<RoomDetails> list = (ArrayList<RoomDetails>) query
				.getResultList();
		return list;
	}

	/*
	 * To insert booking details into database
	 */
	@Override
	public BookingDetails insertBookingDetails(BookingDetails bookingDetails)
			throws HotelException {
		DateTimeFormatter dateFormat = DateTimeFormatter
				.ofPattern("yyyy-MM-dd");
		LocalDate stDate = LocalDate.parse(bookingDetails.getBookedFromDate(),
				dateFormat);
		LocalDate endDate = LocalDate.parse(bookingDetails.getBookedToDate(),
				dateFormat);
		Period period = Period.between(stDate, endDate);
		Double diff = (double) period.getDays();
		RoomDetails details = entityManager.find(RoomDetails.class,
				bookingDetails.getRoomId());
		Double amount = details.getPerNightRate() * diff;
		bookingDetails.setAmount(amount);
		bookingDetails.setBookedFrom(Date.valueOf(stDate));
		bookingDetails.setBookedTo(Date.valueOf(endDate));
		System.out.println(bookingDetails);
		entityManager.persist(bookingDetails);
		RoomDetails roomDetails=entityManager.find(RoomDetails.class, bookingDetails.getRoomId());
		roomDetails.setAvailability("NA");
		entityManager.merge(roomDetails);
		entityManager.flush();
		return bookingDetails;
	}

	/*
	 * To retrieve user Id
	 */
	@Override
	public User fetchUserId(User user) throws HotelException {

		return null;
	}

	/*
	 * To retrieve bookings for a particular hotel based on hotel Id
	 */
	@Override
	public ArrayList<BookingDetails> retrieveGuestList(String hotelId)
			throws HotelException {

		return null;
	}

	/*
	 * To validate user name
	 */
	@Override
	public boolean validateName(User user) throws HotelException {
		boolean res = false;

		return res;
	}

	/*
	 * To retrieve booking status based on booking details
	 */
	public boolean bookingStatus(int id) throws HotelException {
		boolean res= false;
		System.out.println("Id"+id);
		Query query = entityManager.createNamedQuery("bookingstatus");
		query.setParameter("uid", id);
		ArrayList<BookingDetails> list= (ArrayList<BookingDetails>) query.getResultList();
		System.out.println(list);
		if (!list.isEmpty())
			res = true;
		return res;
	}

	/*
	 * To modify hotel details
	 */
	@Override
	public boolean modifyHotel(Hotel hotel) throws HotelException {
		System.out.println(hotel.getHotelId());
		entityManager.merge(hotel);
		entityManager.flush();
		result = true;
		return result;
	}

	/*
	 * To modify room details
	 */
	@Override
	public boolean modifyRoom(RoomDetails details) throws HotelException {

		return result;
	}

	/*
	 * To validate hotel Id
	 */
	public boolean validateHotelId(Hotel hotel) throws HotelException {
		new HotelException("Invalid Hotel Id");

		return false;
	}

	@Override
	public ArrayList<Hotel> getHotelList(int hotelId) {
		Query query = entityManager.createNamedQuery("retrieveHotels");
		query.setParameter("id", hotelId);
		ArrayList<Hotel> list = (ArrayList<Hotel>) query.getResultList();
		return list;
	}

	@Override
	public boolean checkHotelId(Integer hotelId) {
		// TODO Auto-generated method stub
		boolean res=false;
		Query query = entityManager.createNamedQuery("checkhotel");
		query.setParameter("id", hotelId);
		ArrayList<RoomDetails> list = (ArrayList<RoomDetails>) query.getResultList();
		if (!list.isEmpty())
			res = true;
		return res;
	}
}
