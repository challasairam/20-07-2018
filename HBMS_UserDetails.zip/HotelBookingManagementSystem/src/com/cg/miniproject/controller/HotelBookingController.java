package com.cg.miniproject.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;
import com.cg.miniproject.service.IHotelBookingService;

@Controller("/hbms")
public class HotelBookingController {
	@Autowired
	IHotelBookingService service;

	@RequestMapping("index")
	public ModelAndView getHomePage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("home");
		return view;
	}

	@RequestMapping("login")
	public ModelAndView getLoginPage() {
		ModelAndView view = new ModelAndView("login", "user1", new User());
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("User");
		roles.add("Employee");
		roles.add("Admin");
		view.addObject("roles", roles);
		return view;
	}

	@RequestMapping("register")
	public ModelAndView getRegisterPage() {
		ModelAndView view = new ModelAndView("register", "user", new User());
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("User");
		roles.add("Employee");
		roles.add("Admin");
		view.addObject("roles", roles);
		return view;
	}

	@RequestMapping(value = "registerDetails", method = RequestMethod.POST)
	public ModelAndView storeDetails(@ModelAttribute("user") @Valid User user,
			BindingResult result) {
		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("register", "user", user);
			ArrayList<String> roles = new ArrayList<String>();
			roles.add("User");
			roles.add("Employee");
			roles.add("Admin");
			view.addObject("roles", roles);
		} else {
			try {
				boolean res = service.register(user);
				if (res) {
					System.out.println("success");
				} else {
					System.out.println("failure");
				}
			} catch (HotelException e) {
			}
			view.setViewName("home");

		}
		return view;

	}

	@RequestMapping(value = "fetchLoginDetails", method = RequestMethod.POST)
	public ModelAndView getDetails(@ModelAttribute("user1") @Valid User user,
			BindingResult result, HttpServletRequest request) {
		HttpSession session = request.getSession();
		ModelAndView view = new ModelAndView();

		System.out.println("Login Page");
		if (result.hasErrors()) {
			view = new ModelAndView("login", "user1", user);
			ArrayList<String> roles = new ArrayList<String>();
			roles.add("User");
			roles.add("Employee");
			roles.add("Admin");
			view.addObject("roles", roles);
		} else {
			try {
				User user1 = service.login(user);

				if (null != user1) {
					session.setAttribute("username", user1.getUserName());
					session.setAttribute("userid", user1.getUserId());
					if (user.getRole().equals("Admin")) {
						view = new ModelAndView("DisplayForAdmin", "hotel",
								new Hotel());
					} else {

						ArrayList<Hotel> hotels = service.getHotelList();

						if (!hotels.isEmpty()) {
							view = new ModelAndView("DisplayForUser", "room",
									new RoomDetails());
							view.addObject("m", "Hi");
							view.addObject("hotelList", hotels);

						} else {
							String msg = "No hotels are available for Booking!";
							view.addObject("msg", msg);
						}

					}
				} else {
					view = new ModelAndView("login", "user1", user);
					ArrayList<String> roles = new ArrayList<String>();
					roles.add("User");
					roles.add("Employee");
					roles.add("Admin");
					view.addObject("roles", roles);
					view.addObject("message", "Login Failed");
				}

			} catch (HotelException e) {

			}

		}
		return view;
	}

	@RequestMapping("getRoomDetails")
	public ModelAndView getRoomDetails(
			@ModelAttribute("room") RoomDetails details) {
		ModelAndView view = new ModelAndView();
		try {
			boolean res = service.checkHotelId(details.getHotelId());
			if (res) {
				ArrayList<RoomDetails> list = service.getRoomDetails(details
						.getHotelId());
				System.out.println(list);
				if (!list.isEmpty()) {
					ArrayList<Hotel> hotels = service.getHotelList();
					view = new ModelAndView("DisplayForUser", "room",
							new RoomDetails());
					view.addObject("hotelList", hotels);
					view.addObject("roomDetails", list);

				} else {
					view = new ModelAndView("DisplayForUser", "room",
							new RoomDetails());
					String msg = "No rooms are available in this hotel for Booking!";
					view.addObject("rmsg", msg);
				}
			}
			else {
				view = new ModelAndView("DisplayForUser", "room",
						new RoomDetails());
				String msg = "No hotel exists with such hotel id!";
				view.addObject("hmsg", msg); 
			}

		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return view;

	}

	@RequestMapping("BookRoom")
	public ModelAndView bookARoom(@ModelAttribute("room") RoomDetails details) {

		BookingDetails bookingDetails = new BookingDetails();
		ModelAndView view = new ModelAndView("BookRoom", "book", bookingDetails);
		view.addObject("roomId", details.getRoomId());
		return view;
	}

	@RequestMapping("insertBooking")
	public ModelAndView insertBookingDetails(
			@ModelAttribute("book") BookingDetails bookingDetails,
			HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		ModelAndView view = new ModelAndView();
		Object s = session.getAttribute("userid");
		bookingDetails.setUserId(Integer.parseInt(s.toString()));
		try {
			BookingDetails bookingDetails2 = service
					.insertBookingDetails(bookingDetails);
			view.addObject("id", bookingDetails2.getBookingId());
			view = new ModelAndView("DisplayForUser", "room", new RoomDetails());
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return view;
	}

	@RequestMapping("bookingStatus")
	public ModelAndView viewBookingStatus(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		ModelAndView view = new ModelAndView();
		BookingDetails details = new BookingDetails();
		Object s = session.getAttribute("userid");
		details.setUserId(Integer.parseInt(s.toString()));
		try {
			boolean r = service.bookingStatus(details.getUserId());
			System.out.println(r);
			if (r) {
				view = new ModelAndView("DisplayForUser", "room",
						new RoomDetails());
				String statusmsg1 = "You have already booked!";
				view.addObject("statusmsg1", statusmsg1);
			} else {
				view = new ModelAndView("DisplayForUser", "room",
						new RoomDetails());
				String statusmsg2 = "Not yet booked!";
				view.addObject("statusmsg2", statusmsg2);
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return view;
	}

	@RequestMapping("AddHotel")
	public ModelAndView getAddHotelPage() {
		ModelAndView view = new ModelAndView("AddHotel", "hotel", new Hotel());
		return view;

	}

	@RequestMapping("addHotelDetails")
	public ModelAndView saveHotelDetails(
			@ModelAttribute("hotel") @Valid Hotel hotel, BindingResult result) {

		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("AddHotel", "hotel", hotel);
		} else {
			try {
				boolean result2 = service.addHotels(hotel);
				if (result2) {
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new Hotel());
				}

			} catch (HotelException e) {

			}
		}
		return view;

	}

	@RequestMapping("DeleteHotel")
	public ModelAndView getDeleteHotelPage() {
		ModelAndView view = new ModelAndView("DeleteHotel", "hotel",
				new Hotel());
		return view;

	}

	@RequestMapping("deleteHotelDetails")
	public ModelAndView deleteHotelDetails(@ModelAttribute("hotel") Hotel hotel) {
		ModelAndView view = new ModelAndView();
		try {
			boolean result = service.deleteHotel(hotel.getHotelId());
			if (result) {
				view = new ModelAndView("DisplayForAdmin", "hotel", new Hotel());
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return view;

	}

	@RequestMapping("ModifyHotel")
	public ModelAndView getModifyHotelPage() {
		ModelAndView view = new ModelAndView("ModifyHotel", "hotel",
				new Hotel());
		return view;

	}

	@RequestMapping("modifyHotelDetails")
	public ModelAndView modifyHotelDetails(
			@ModelAttribute("hotel") @Valid Hotel hotel, BindingResult result) {
		System.out.println(hotel.getHotelId());
		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("ModifyHotel", "hotel", hotel);
		} else {
			try {
				boolean result2 = service.modifyHotel(hotel);
				if (result2) {
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new Hotel());
				}
			} catch (HotelException e) {

			}
		}

		return view;

	}

	@RequestMapping("getHotelDetailsById")
	public ModelAndView getHotelDetailsById(@ModelAttribute("hotel") Hotel hotel) {

		ModelAndView view = new ModelAndView();
		ArrayList<Hotel> list = service.getHotelList(hotel.getHotelId());
		// System.out.println(list);
		if (!list.isEmpty()) {
			view = new ModelAndView("ModifyHotel", "hotel", new Hotel());
			view.addObject("hotelDetails", list);
		}
		return view;

	}
}