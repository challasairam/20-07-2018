package com.cg.miniproject.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;

public interface IHotelBookingService {
	public boolean register(User user) throws HotelException;

	public User login(User user) throws HotelException;

	public boolean validateName(User user) throws HotelException;

	public boolean addHotels(Hotel hotel) throws HotelException;

	public boolean deleteHotel(Integer id) throws HotelException;

	public boolean addRooms(RoomDetails roomDetails) throws HotelException;

	public boolean deleteRoom(Integer id) throws HotelException;

	public ArrayList<BookingDetails> retrieveBookings(Integer hotelId)
			throws HotelException;

	public ArrayList<BookingDetails> retrieveBookings(LocalDate date)
			throws HotelException;

	public ArrayList<Hotel> getHotelList() throws HotelException;

	public ArrayList<RoomDetails> getRoomDetails(Integer id)
			throws HotelException;

	public BookingDetails insertBookingDetails(BookingDetails bookingDetails)
			throws HotelException;

	public User fetchUserId(User user) throws HotelException;

	public BookingDetails retrieveGuestList(Integer hotelId)
			throws HotelException;

	public boolean viewBookingStatus(Integer userId) throws HotelException;

	public boolean modifyHotel(Hotel hotel2) throws HotelException;

	public boolean modifyRoom(RoomDetails details) throws HotelException;

	public boolean validateHotelId(Integer hotelId) throws HotelException;

	public ArrayList<Hotel> getHotelList(Integer hotelId);

	public ArrayList<RoomDetails> getRoomList(RoomDetails roomDetails);
}
