package com.cg.miniproject.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;

@Repository
@Transactional
public class HotelBookingDaoImpl implements IHotelBookingDao {
	boolean b, result = false;

	@PersistenceContext
	EntityManager entityManager;

	/*
	 * To register a new user/employee
	 */
	@Override
	public boolean register(User user) throws HotelException {

		entityManager.persist(user);
		entityManager.flush();
		b = true;
		return b;
	}

	/*
	 * To login a user/employee
	 */
	public User login(User user) throws HotelException {

		User user2 = null;
		Query query = entityManager.createNamedQuery("login");
		query.setParameter("uname", user.getUserName());
		query.setParameter("pwd", user.getPassword());
		query.setParameter("role", user.getRole());
		ArrayList<User> list = (ArrayList<User>) query.getResultList();
		System.out.println();
		if (!list.isEmpty()) {
			user.setUserId(list.get(0).getUserId());
			user2 = user;
		}

		return user2;
	}

	/*
	 * To add Hotels in the hotel table
	 */
	@Override
	public boolean addHotels(Hotel hotel) throws HotelException {

		entityManager.persist(hotel);
		entityManager.flush();
		result = true;
		return result;
	}

	/*
	 * To delete hotel based on hotel Id
	 */
	@Override
	public boolean deleteHotel(Integer id) throws HotelException {

		Hotel hotel = entityManager.find(Hotel.class, id);
		entityManager.remove(hotel);
		result = true;
		return result;
	}

	/*
	 * To add new rooms for a particular hotel
	 */
	@Override
	public boolean addRooms(RoomDetails roomDetails) throws HotelException {
		
		entityManager.persist(roomDetails);
		entityManager.flush();
		result=true;
		return result;
	}

	/*
	 * To delete rooms for a particular hotel based on room id
	 */
	@Override
	public boolean deleteRooms(Integer id) throws HotelException {
		RoomDetails roomDetails=entityManager.find(RoomDetails.class,id);
		entityManager.remove(roomDetails);
		result=true;
		return result;
	}

	/*
	 * To retrieve bookings for a particular hotel based on hotel Id
	 */
	@Override
	public ArrayList<BookingDetails> retrieveBookings(Integer hotelId)
			throws HotelException {
		Query query = entityManager
				.createQuery("SELECT b FROM BookingDetails b,RoomDetails r,Hotel h WHERE h.hotelId=r.hotelId and b.roomId=r.roomId and h.hotelId=:id");
		query.setParameter("id", hotelId);
		@SuppressWarnings("unchecked")
		ArrayList<BookingDetails> list = (ArrayList<BookingDetails>) query
				.getResultList();
		return list;

	}

	/*
	 * To retrieve bookings for a particular hotel based on Date
	 */
	@Override
	public ArrayList<BookingDetails> retrieveBookings(LocalDate date)
			throws HotelException {

		Date currentDate=Date.valueOf(date);
		Query query=entityManager.createQuery("SELECT b FROM BookingDetails b WHERE :cdate BETWEEN b.bookedFrom AND b.bookedTo");
		query.setParameter("cdate",currentDate);
		@SuppressWarnings("unchecked")
		ArrayList<BookingDetails> list = (ArrayList<BookingDetails>) query
				.getResultList();
		return list;

	}

	/*
	 * To retrieve list of hotels
	 */
	@Override
	public ArrayList<Hotel> getHotelList() throws HotelException {

		Query query = entityManager.createNamedQuery("listAllHotels");
		@SuppressWarnings("unchecked")
		ArrayList<Hotel> list = (ArrayList<Hotel>) query.getResultList();
		return list;
	}

	/*
	 * To retrieve room details based on hotel Id
	 */
	@Override
	public ArrayList<RoomDetails> getRoomDetails(Integer id)
			throws HotelException {

		Query query = entityManager.createNamedQuery("getRoomDetails");
		query.setParameter("id",id);
		@SuppressWarnings("unchecked")
		ArrayList<RoomDetails> list = (ArrayList<RoomDetails>) query
				.getResultList();
		return list;
	}

	/*
	 * To insert booking details into database
	 */
	@Override
	public boolean insertBookingDetails(BookingDetails bookingDetails)
			throws HotelException {
		boolean result = false;

		return result;
	}

	/*
	 * To retrieve user Id
	 */
	@Override
	public User fetchUserId(User user) throws HotelException {

		return null;
	}

	/*
	 * To retrieve bookings for a particular hotel based on hotel Id
	 */
	@Override
	public BookingDetails retrieveGuestList(Integer hotelId)
			throws HotelException {
		Query query=entityManager.createQuery("SELECT sum(b.noOfAdults) FROM BookingDetails b,RoomDetails r,Hotel h WHERE h.hotelId=r.hotelId and b.roomId=r.roomId and h.hotelId=:id");
		query.setParameter("id",hotelId);
		Long result = (Long) query.getSingleResult();
	      Query query1=entityManager.createQuery("SELECT sum(b.noOfChildren) FROM BookingDetails b,RoomDetails r,Hotel h WHERE h.hotelId=r.hotelId and b.roomId=r.roomId and h.hotelId=:id");
	      query1.setParameter("id",hotelId);
	      Long result1 = (Long) query1.getSingleResult();
	      System.out.println(result+" "+result1);
		BookingDetails details=new BookingDetails();
		if(null!=result && null !=result1)
		{
		details.setNoOfAdults(result.intValue());
		details.setNoOfChildren(result1.intValue());
		}
		else
		{
			details=null;
		}
		return details;
	}

	

	/*
	 * To retrieve booking status based on booking details
	 */
	public boolean bookingStatus(BookingDetails details) throws HotelException {

		return false;
	}

	/*
	 * To modify hotel details
	 */
	@Override
	public boolean modifyHotel(Hotel hotel) throws HotelException {
		System.out.println(hotel.getHotelId());
		entityManager.merge(hotel);
		entityManager.flush();
		result = true;
		return result;
	}

	/*
	 * To modify room details
	 */
public boolean modifyRoom(RoomDetails details) throws HotelException {
		
		entityManager.merge(details);
		entityManager.flush();
		result=true;
		return result;
	}

	/*
	 * To validate hotel Id
	 */
	public boolean validateHotelId(Integer hotelId) throws HotelException {
		Query query=entityManager.createNamedQuery("retrieveHotels");
		query.setParameter("id",hotelId);
		ArrayList<Hotel> list = (ArrayList<Hotel>) query.getResultList();
		if(!list.isEmpty())
			result=true;
		return result;
	}

	@Override
	public ArrayList<Hotel> getHotelList(Integer hotelId) {
		Query query = entityManager.createNamedQuery("retrieveHotels");
		query.setParameter("id", hotelId);
		ArrayList<Hotel> list = (ArrayList<Hotel>) query.getResultList();
		return list;
	}
	
	@Override
	public ArrayList<RoomDetails> getRoomList(RoomDetails roomDetails) {
		// TODO Auto-generated method stub
		Query query=entityManager.createNamedQuery("roomlist");
		query.setParameter("hid",roomDetails.getHotelId());
		query.setParameter("rid",roomDetails.getRoomId());
		ArrayList<RoomDetails> list=(ArrayList<RoomDetails>) query.getResultList();
		System.out.println(list);
		return list;
	}

	@Override
	public boolean validateName(User user) throws HotelException {
		// TODO Auto-generated method stub
		return false;
	}
}
